#include "BotHandler.h"
#include "ECommand.h"

#include <UniversalTelegramBot.h>

BotHandler::BotHandler(UniversalTelegramBot *bot) : bot(bot)
{
}

void BotHandler::processMessages(std::function<void(ECommand)> msgProcessor)
{
    int numberOfMsgs = bot->getUpdates(bot->last_message_received + 1);

    Serial.println("NUMBER OF MSGS");
    Serial.println(numberOfMsgs);

    while (numberOfMsgs)
    {
        Serial.println("Comando recibido");

        for (int i = 0; i < numberOfMsgs; i++)
        {
            ECommand cmd = getCommandAtIndex(i);
            msgProcessor(cmd);
        }

        numberOfMsgs = bot->getUpdates(bot->last_message_received + 1);
    }
}

void BotHandler::sendMessage(String message)
{
    if (currentChatID != "none" && bot)
    {
        bot->sendMessage(currentChatID, message, "");
    }
}

ECommand BotHandler::getCommandAtIndex(int index)
{
    telegramMessage msg = bot->messages[index];
    currentChatID = msg.chat_id;
    String text = msg.text;

    ECommand cmd = hashit(text.c_str());

    return cmd;
}
