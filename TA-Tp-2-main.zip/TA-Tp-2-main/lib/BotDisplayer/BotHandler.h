#ifndef _BOT_HANDLER
#define _BOT_HANDLER

#include "ECommand.h"

#include <functional>
#include <UniversalTelegramBot.h>
#include <Arduino.h>

class UniversalTelegramBot;

class BotHandler
{
public:
    BotHandler(UniversalTelegramBot *bot);

    void processMessages(std::function<void(ECommand)> msgProcessor);
    void sendMessage(String message);

private:
    UniversalTelegramBot *bot;
    String currentChatID = "none";

    enum ECommand getCommandAtIndex(int index);
};

#endif