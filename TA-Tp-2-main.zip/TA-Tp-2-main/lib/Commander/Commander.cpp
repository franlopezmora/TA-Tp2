#include "Commander.h"
#include "BotHandler.h"
#include "LedHandler.h"
#include "Displayer.h"
#include "DHTHandler.h"
#include "PTIoTHandler.h"
#include "PotentiometerHandler.h"

#include <Arduino.h>

Commander::Commander(BotHandler *bot, LedHandler *ledHandler, DHTHandler *dhtHandler, PTIoTHandler *ptiotHandler, Displayer *displayer, PotentiometerHandler *poteHandler)
    : bot(bot),
      ledHandler(ledHandler),
      dhtHandler(dhtHandler),
      ptiotHandler(ptiotHandler),
      displayer(displayer),
      poteHandler(poteHandler)
{
    // asignamos a cada comando una funcion
    commandMap[eStart] = [this]()
    { start(); };
    commandMap[eLed23On] = [this]()
    { led23On(); };
    commandMap[eLed23Off] = [this]()
    { led23Off(); };
    commandMap[eLed2On] = [this]()
    { led2On(); };
    commandMap[eLed2Off] = [this]()
    { led2Off(); };
    commandMap[eDHT22] = [this]()
    { showDHT22(); };
    commandMap[ePote] = [this]()
    { showPote(); };
    commandMap[ePlatiot] = [this]()
    { platiot(); };
    commandMap[eDisplayLed] = [this]()
    { displayLed(); };
    commandMap[eDisplayPote] = [this]()
    { displayPote(); };
    commandMap[eDisplayDHT22] = [this]()
    { displayDHT22(); };
}

void Commander::initialize()
{
    displayer->initialize();
}

void Commander::executeCommand(ECommand cmd)
{
    auto it = commandMap.find(cmd);
    if (it != commandMap.end())
    {
        lastCommandExecuted = cmd;
        it->second();
    }
    else
    {
        displayer->print("Comando Desconocido :o");
    }
}

void Commander::update()
{
    // if the last command executed was a command that fed data to the display,
    // execute it again
    switch (lastCommandExecuted)
    {
    case ECommand::eDisplayDHT22:
    case ECommand::eDisplayLed:
    case ECommand::eDisplayPote:
        executeCommand(lastCommandExecuted);
        break;
    default:
        break;
    }
}

void Commander::start()
{
    displayer->print("Iniciando la comunicación con el bot...");

    String welcomeMessage = "¡Bienvenido al Bot de Control de la Placa de Desarrollo! 😄\n\n";
    welcomeMessage += "Aquí tienes los comandos que puedes utilizar:\n\n";

    welcomeMessage += "/start - Inicia la comunicación con el bot y recibe este mensaje de bienvenida.\n\n";

    welcomeMessage += "/led<led><on/off> - Enciende o apaga un LED de la placa.\n";
    welcomeMessage += "  • /led23on - Enciende el LED verde.\n";
    welcomeMessage += "  • /led2off - Apaga el LED azul.\n\n";

    welcomeMessage += "/dht22 - Muestra los valores actuales de temperatura y humedad del sensor DHT22.\n\n";

    welcomeMessage += "/pote - Muestra el valor de voltaje leído por el potenciómetro.\n\n";

    welcomeMessage += "/platiot - Envía los valores de temperatura y humedad del DHT22 a la plataforma IoT Things Speak.\n\n";

    welcomeMessage += "/display<comando> - Muestra el estado de los componentes en el display OLED de la placa.\n";
    welcomeMessage += "  • Ejemplos:\n";
    welcomeMessage += "    - /displayled - Muestra el estado actual del LED (encendido/apagado).\n";
    welcomeMessage += "    - /displaypote - Muestra el estado del potenciómetro.\n";
    welcomeMessage += "    - /displaydht22 - Muestra los valores del sensor DHT22.\n\n";

    welcomeMessage += "Si ingresas un comando no reconocido, se mostrará un mensaje de error en el display.\n\n";
    welcomeMessage += "¡Utiliza estos comandos para controlar los componentes de tu placa! 😊";

    bot->sendMessage(welcomeMessage);
}

void Commander::led23On()
{
    displayer->print("Encendiendo el LED Verde en el GPIO...");

    ledHandler->turnOnGreen();
    bot->sendMessage("LED verde encendido!!");
}

void Commander::led23Off()
{
    displayer->print("Apagando el LED Verde en el GPIO...");

    ledHandler->turnOffGreen();
    bot->sendMessage("LED verde apagado!!");
}

void Commander::led2On()
{
    displayer->print("Encendiendo el LED Azul en el GPIO...");

    ledHandler->turnOnBlue();
    bot->sendMessage("LED azul encendido!!");
}

void Commander::led2Off()
{
    displayer->print("Apagando el LED Azul en el GPIO...");

    ledHandler->turnOffBlue();
    bot->sendMessage("LED azul apagado!!");
}

void Commander::showDHT22()
{
    displayer->print("Mostrando valores de temperatura y humedad del DHT22...");
    SensorData dataDHT = dhtHandler->getTemperatureAndHumidity();
    String message = "La temperatura es de: " + String(dataDHT.temperature) + " °C\n";
    message += "La humedad es de: " + String(dataDHT.humidity) + " %";
    bot->sendMessage(message);
}

void Commander::showPote()
{
    displayer->print("Mostrando el voltaje del potenciómetro...");

    float value = poteHandler->getPotentiometerValue();
    String message = "El voltaje del potenciometro es de: " + String(value) + " V";

    bot->sendMessage(message);
}

void Commander::platiot()
{
    SensorData data = dhtHandler->getTemperatureAndHumidity();
    ptiotHandler->updateValuesDHT(data);
    displayer->print("Enviando datos del DHT22 a la plataforma IoT...");
    bot->sendMessage("https://thingspeak.com/channels/2677469");
}

void Commander::displayLed()
{
    String message = "----LED STATUS----\n";
    String led23Status = (ledHandler->isBlueLedOn()) ? "Encendido\n" : "Apagado\n";
    String led2Status = (ledHandler->isGreenLedOn()) ? "Encendido\n" : "Apagado\n";
    message += "Led Verde: " + led2Status;
    message += "Led Azul: " + led23Status;
    displayer->print(message);
}

void Commander::displayPote()
{
    String message = "----POTENTIOMETER STATUS----\n";
    String poteStatus = "Voltaje: " + String(poteHandler->getPotentiometerValue()) + " V\n";
    message += poteStatus;

    displayer->print(message);
}

void Commander::displayDHT22()
{
    SensorData dataDHT = dhtHandler->getTemperatureAndHumidity();
    String message = "----DHT22 STATUS----\n";
    message += "Temp: " + String(dataDHT.temperature) + " *C\n";
    message += "Humidity: " + String(dataDHT.humidity) + " %";
    displayer->print(message);
}