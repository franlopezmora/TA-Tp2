#ifndef _COMMANDER
#define _COMMANDER

#include "ECommand.h"
#include <functional>
#include <map>
#include <string>

class BotHandler;
class LedHandler;
class Displayer;
class DHTHandler;
class PTIoTHandler;
class PotentiometerHandler;

class Commander
{
public:
    Commander(BotHandler *bot, LedHandler *ledHandler, DHTHandler *dhtHandler, PTIoTHandler *ptiotHandler, Displayer *displayer, PotentiometerHandler *poteHandler);

    void initialize();
    void executeCommand(ECommand cmd);

    void update();
private:
    std::map<ECommand, std::function<void()>> commandMap;

    BotHandler *bot;
    LedHandler *ledHandler;
    DHTHandler *dhtHandler;
    PTIoTHandler *ptiotHandler;
    Displayer *displayer;
    PotentiometerHandler *poteHandler;

    ECommand lastCommandExecuted = ECommand::eUnknown;

    void start();
    void led23On();
    void led23Off();
    void led2On();
    void led2Off();
    void showDHT22();
    void showPote();
    void platiot();
    void displayLed();
    void displayPote();
    void displayDHT22();
};

#endif