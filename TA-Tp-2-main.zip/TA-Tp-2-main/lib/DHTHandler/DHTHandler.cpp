#include "DHTHandler.h"
#include <Arduino.h>

DHTHandler::DHTHandler(DHT *dht) : dht(dht)
{
}

SensorData DHTHandler::getTemperatureAndHumidity()
{
    SensorData data;
    data.temperature = this->dht->readTemperature();
    data.humidity = this->dht->readHumidity();
    return data;
}
