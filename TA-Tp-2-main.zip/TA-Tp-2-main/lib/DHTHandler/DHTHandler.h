#include <DHT.h>
#ifndef _DHT_HANDLER
#define _DHT_HANDLER

struct SensorData
{
    int temperature;
    int humidity;
};

class DHTHandler
{
public:
    DHTHandler(DHT *dht);
    SensorData getTemperatureAndHumidity();

private:
    DHT *dht;
};

#endif