#include "Displayer.h"

#include <Adafruit_SH110X.h>

#define TEXT_SIZE 1
#define DISTANCE_BETWEEN_LINES 19
#define MAX_LINE_LENGTH 19

Displayer::Displayer(Adafruit_SH1106G *display) : display(display)
{
}

void Displayer::initialize()
{
    // Inicializar pantalla OLED
    display->begin(0x3c, true); // Dirección por defecto: 0x3C
    display->setTextSize(TEXT_SIZE);
    display->setTextColor(SH110X_WHITE);
}

void Displayer::print(String text)
{
    Serial.println(text);

    display->clearDisplay();

    std::vector<String> strings = splitText(text);

    // printStrings(strings);
    display->setCursor(0, 0);
    display->print(text);

    display->display();
}

std::vector<String> Displayer::splitText(String text)
{
    std::vector<String> lines;
    String remainingText = text;

    while (remainingText.length() > 0)
    {
        // si el texto es menor que el limite de linea, escapamos del while
        if (remainingText.length() <= MAX_LINE_LENGTH)
        {
            lines.push_back(remainingText);
            break;
        }

        // sino, buscamos el ultimo espacio de la palabra
        int lastSpace = remainingText.lastIndexOf(' ', MAX_LINE_LENGTH);

        String lineToAdd;

        if (lastSpace != -1)
        {
            // si hay un espacio, partimos todo el texto desde ese espacio
            lineToAdd = remainingText.substring(0, lastSpace);
            remainingText = remainingText.substring(lastSpace + 1); // removemos del texto restante la parte que agregamos
        }
        else
        {
            // si no hay espacio, partimos la palabra
            lineToAdd = remainingText.substring(0, MAX_LINE_LENGTH - 1) + "-";
            remainingText = remainingText.substring(MAX_LINE_LENGTH - 1); // removemos del texto restante la parte que agregamos
        }

        // Add the processed line to the lines vector
        lines.push_back(lineToAdd);
    }

    return lines;
}

void Displayer::printStrings(std::vector<String> stringsToDisplay, int initialY, int margin)
{
    int currentY = initialY;

    for (size_t i = 0; i < stringsToDisplay.size(); ++i)
    {
        display->setCursor(margin, currentY);

        String line = stringsToDisplay[i];
        display->print(line);

        currentY += DISTANCE_BETWEEN_LINES + TEXT_SIZE; 
    }
}