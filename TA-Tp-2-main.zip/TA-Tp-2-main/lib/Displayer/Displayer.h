#ifndef _DISPLAYER
#define _DISPLAYER

#include <vector>
#include <Arduino.h>

class Adafruit_SH1106G;

class Displayer
{
public:
    Displayer(Adafruit_SH1106G *display);

    void initialize();

    void print(String text);

private:
    Adafruit_SH1106G *display;

    std::vector<String> splitText(String text);

    void printStrings(std::vector<String> stringsToDisplay, int initialY = 0, int margin = 10);
};

#endif