#include "LedHandler.h"
#include <Arduino.h>

LedHandler::LedHandler(int greenLed, int blueLed) : greenLed(greenLed), blueLed(blueLed)
{
}

void LedHandler::turnOnGreen()
{
    bIsGreenLedOn = true;    
    turnOn(greenLed);
}
void LedHandler::turnOffGreen()
{
    bIsGreenLedOn = false;    
    turnOff(greenLed);
}

void LedHandler::turnOnBlue()
{
    bIsBlueLedOn = true;
    turnOn(blueLed);
}

void LedHandler::turnOffBlue()
{
    bIsBlueLedOn = false;    
    turnOff(blueLed);
}

void LedHandler::turnOn(int pin)
{
    digitalWrite(pin, HIGH);
}

void LedHandler::turnOff(int pin)
{
    digitalWrite(pin, LOW);
}

bool LedHandler::isGreenLedOn()
{
    return bIsGreenLedOn;
}

bool LedHandler::isBlueLedOn()
{
    return bIsBlueLedOn;
}
