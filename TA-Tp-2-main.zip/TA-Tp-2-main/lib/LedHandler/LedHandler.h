#ifndef _LED_HANDLER
#define _LED_HANDLER

class LedHandler
{
public:
    LedHandler(int greenLed, int blueLed);

    void turnOnGreen();
    void turnOffGreen();

    void turnOnBlue();
    void turnOffBlue();
    
    bool isGreenLedOn();
    bool isBlueLedOn();

private:
    int greenLed;
    int blueLed;
    bool bIsBlueLedOn = false;
    bool bIsGreenLedOn = false;

    void turnOn(int pin);
    void turnOff(int pin);
};

#endif