#include "PTIoTHandler.h"

PTIoTHandler::PTIoTHandler(String apikey) : apiKey(apikey)
{
}

void PTIoTHandler::updateValuesDHT(SensorData data)
{
    String url = server;
    url += "?api_key=" + this->apiKey;
    url += "&field1=" + String(data.temperature);
    url += "&field2=" + String(data.humidity);

    HTTPClient http;
    http.begin(url);
    int httpCode = http.GET();

    if (httpCode > 0)
    {
        String payload = http.getString();
        Serial.println("Datos enviados a ThingSpeak: " + payload);
    }
    else
    {
        Serial.println("Error en la conexión: " + String(httpCode));
    }
    http.end();
}
