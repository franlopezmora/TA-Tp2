#include <HTTPClient.h>
#include <DHTHandler.h>
#ifndef _PTIoT_HANDLER
#define _PTIoT_HANDLER

class PTIoTHandler
{
public:
    PTIoTHandler(String apikey);

    void updateValuesDHT(SensorData data);
private:
    String apiKey;
    String server = "http://api.thingspeak.com/update";
};


#endif
