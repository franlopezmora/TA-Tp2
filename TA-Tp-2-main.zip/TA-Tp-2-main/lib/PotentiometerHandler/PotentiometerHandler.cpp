#include "PotentiometerHandler.h"
#include <Arduino.h>

PotentiometerHandler::PotentiometerHandler(int pin)
    : pin(pin)
{
}

void PotentiometerHandler::initialize()
{
    pinMode(pin, INPUT);
}

float PotentiometerHandler::getPotentiometerValue()
{
    return 3.3 * analogRead(pin) / 4095.0;
}
