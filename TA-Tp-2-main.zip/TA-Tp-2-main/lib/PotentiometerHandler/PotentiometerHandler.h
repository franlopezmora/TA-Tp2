#ifndef _POTE_HANDLER
#define _POTE_HANDLER

class PotentiometerHandler
{
public:
    PotentiometerHandler(int pin);

    void initialize();

    float getPotentiometerValue();
private:
    int pin;
};


#endif
