#include "ECommand.h"

ECommand hashit(std::string const& inString) {
    if (inString == "/start") return eStart;
    if (inString == "/led23on") return eLed23On;
    if (inString == "/led23off") return eLed23Off;
    if (inString == "/led2on") return eLed2On;
    if (inString == "/led2off") return eLed2Off;
    if (inString == "/dht22") return eDHT22;
    if (inString == "/pote") return ePote;
    if (inString == "/platiot") return ePlatiot;
    if (inString == "/displayled") return eDisplayLed;
    if (inString == "/displaypote") return eDisplayPote;
    if (inString == "/displaydht22") return eDisplayDHT22;

    return eUnknown;
}