#ifndef COMMANDS_H
#define COMMANDS_H

#include <string>

enum ECommand
{
    eStart,
    eLed23On,
    eLed23Off,
    eLed2On,
    eLed2Off,
    eDHT22,
    ePote,
    ePlatiot,
    eDisplayLed,
    eDisplayPote,
    eDisplayDHT22,
    eUnknown 
};

// funcion para convertir de string a ENUM
ECommand hashit(std::string const &inString);

#endif