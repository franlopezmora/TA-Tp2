#include <Arduino.h>

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h>

#include <Adafruit_SH110X.h>
#include <Wire.h>
#include <DHT.h>

#include <vector>

#include "ECommand.h"
#include "BotHandler.h"
#include "Commander.h"
#include "LedHandler.h"
#include "Displayer.h"
#include "DHTHandler.h"
#include "PTIoTHandler.h"
#include "PotentiometerHandler.h"

#define GREEN_LED_PIN 23
#define BLUE_LED_PIN 2
#define DHT22_PIN 33
#define POTENTIOMETER_PIN 32

// function declarations
void connectWiFi();
void processMessage(ECommand cmd);

// global variables

// necesitamos si o si este ssid y pass para que ande
// dentro de WOKWI !!!
const char *SSID = "Wokwi-GUEST";
const char *PASS = "";

const char *BOT_TOKEN = "7553670914:AAGr8yD4nD69Che1WooY-MvNKM7GX-k7z_4";
const char *PTIOT_API_KEY = "87FSJ6ZQ62H02XTN";

const unsigned long CHECK_INTERVAL = 500;

unsigned long lastCheckTime = 0;

WiFiClientSecure secured_client;
UniversalTelegramBot *telegramBot = new UniversalTelegramBot(BOT_TOKEN, secured_client);

DHT *dht = new DHT(DHT22_PIN, DHT22);
Adafruit_SH1106G *display = new Adafruit_SH1106G(128, 64, &Wire, -1);

BotHandler *bot = new BotHandler(telegramBot);
LedHandler *ledHandler = new LedHandler(GREEN_LED_PIN, BLUE_LED_PIN);
DHTHandler *dhtHandler = new DHTHandler(dht);
PTIoTHandler *ptiotHandler = new PTIoTHandler(PTIOT_API_KEY);
Displayer *displayer = new Displayer(display);
PotentiometerHandler *poteHandler = new PotentiometerHandler(POTENTIOMETER_PIN);
Commander commander = Commander(bot, ledHandler, dhtHandler, ptiotHandler, displayer, poteHandler);

void setup()
{
    Serial.begin(9600);

    pinMode(GREEN_LED_PIN, OUTPUT);
    pinMode(BLUE_LED_PIN, OUTPUT);

    commander.initialize();

    connectWiFi();

    dht->begin();
}

void loop()
{
    unsigned long currentTime = millis();
    if (currentTime - lastCheckTime >= CHECK_INTERVAL)
    {
        lastCheckTime = currentTime;

        bot->processMessages(processMessage);
    }
    commander.update();
}

void processMessage(ECommand cmd)
{
    commander.executeCommand(cmd);
}

void connectWiFi()
{
    displayer->print("Conectando a la red...");
    WiFi.begin(SSID, PASS);

    secured_client.setCACert(TELEGRAM_CERTIFICATE_ROOT);

    while (WiFi.status() != WL_CONNECTED)
    {
        Serial.print(".");
        delay(500);
    }

    String msg = "\nConectado a la red wifi. Dirección IP: " + WiFi.localIP().toString();
    displayer->print("\nConectado a la red wifi.");
}